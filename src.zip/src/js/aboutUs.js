import {
  loadDynamicContent,
} from './utilities.mjs'

loadDynamicContent ();
